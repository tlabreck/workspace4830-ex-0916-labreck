package util;

public interface Info {
   public String projectName = "webproject-ex-0916-labreck";
   public String searchWebName = "simpleSearchHB.html";
   public String insertWebName = "simpleInsertHB.html";
}
